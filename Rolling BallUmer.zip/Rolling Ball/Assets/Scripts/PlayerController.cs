﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour {
	private Rigidbody rb;
	public float speed;
	// Use this for initialization
	void Start () {
		//input
		rb = GetComponent<Rigidbody>();
		speed = 10;

	}
	
	// Update is called once per frame
	// Most game code should go here
	void Update () {
		
	}

	// Called befor doing any Physics Calculations 
	// Physics Updates
	void FixedUpdate () {
		float moveHorizontal = Input.GetAxis ("Horizontal");
		float moveVertidal = Input.GetAxis ("Vertical");
		Vector3 movement = new Vector3 (moveHorizontal,0.0f , moveVertidal);
		//Rigidbody
		rb.AddForce(movement * speed);
	}
}
